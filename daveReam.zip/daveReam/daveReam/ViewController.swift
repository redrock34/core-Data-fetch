

import UIKit;import CoreData

class ViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    

    var imagePicker: UIImagePickerController!
    
    
    var text = UITextField()
    var i1 = UIImageView()
    var i2 = UIImageView()
    var btnSave = UIButton()
    var btnImrt = UIButton()
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        // Set photoImageView to display the selected image.
        
        i1.image = selectedImage
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        [text,i1,i2,btnSave,btnImrt].forEach{
            view.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
            $0.backgroundColor = .green
        }
        
        btnSave.setTitle("Save", for: .normal)
        btnImrt.setTitle("Import", for: .normal)
        
        text.placeholder = "Enter #"
        
        
        
        
        
        NSLayoutConstraint.activate([
            text.topAnchor.constraint(equalTo: view.topAnchor, constant : 0),
            text.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            text.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            text.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
            
            i1.topAnchor.constraint(equalTo: text.bottomAnchor, constant : 0),
            i1.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            i1.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            i1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
            i2.topAnchor.constraint(equalTo: i1.bottomAnchor, constant : 0),
            i2.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            i2.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            i2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
            
            btnImrt.topAnchor.constraint(equalTo: i2.bottomAnchor, constant : 0),
            btnImrt.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            btnImrt.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            btnImrt.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
            
            btnSave.topAnchor.constraint(equalTo: btnImrt.bottomAnchor, constant : 0),
            btnSave.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.2),
            btnSave.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.0),
            btnSave.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
            
            ])
        
        
        
        btnImrt.addTarget(self, action: #selector(add), for: .touchUpInside)
        btnSave.addTarget(self, action: #selector(save), for: .touchUpInside)
        
        
    }
    
    @objc func add(){
        imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
        view.bringSubviewToFront(i1)
        i1.contentMode = .scaleAspectFit
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "Your altered image has been saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }
    @objc func save(){
        
        let jake = i1.screenshot(for: i1.frame).pngData()
//        let vex = self.view.screenshot(for: i1.frame, clipToBounds: true, with: UIImage(named: "np.png")).pngData()
                 guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                 let managedContext = appDelegate.persistentContainer.viewContext
                 let entity = NSEntityDescription.entity(forEntityName: "Item", in: managedContext)!
                 let item = NSManagedObject(entity: entity, insertInto: managedContext)
                 let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
                 
                 
                 if let data = jake{
                     item.setValue(data, forKey: "image")
                     print(data)
                 }
                 
                 
                 
                 
                 do {
                     let result = try? managedContext.fetch(fetch) as? [Item]
                     print("Queen",result?.count)
                     try? managedContext.save()
                     
                     
                     
                 }
                 catch {
                     print("Could not save")
                 }
        
        
        i1.image = nil
    }
    

         
           
           
}

extension UIImageView {
    /// Takes a screenshot of a UIView, with an option to clip to view bounds and place a waterwark image
    /// - Parameter rect: offset and size of the screenshot to take
    /// - Parameter clipToBounds: Bool to check where self.bounds and rect intersect and adjust size so there is no empty space
    /// - Parameter watermark: UIImage of the watermark to place on top
    func screenshot(for rect: CGRect, clipToBounds: Bool = true, with watermark: UIImage? = nil) -> UIImage {
        var imageRect = rect
        if clipToBounds {
            imageRect = bounds.intersection(rect)
        }
        return UIGraphicsImageRenderer(bounds: imageRect).image { _ in
            drawHierarchy(in: CGRect(origin: .zero, size: bounds.size), afterScreenUpdates: true)
            watermark?.draw(in: CGRect(x: 0, y: 0, width: 32, height: 32))
        }
    }
}

